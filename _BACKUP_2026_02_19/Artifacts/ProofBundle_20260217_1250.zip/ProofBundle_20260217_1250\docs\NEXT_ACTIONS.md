# SIRADAKİ AKSİYONLAR (NEXT ACTIONS)

Öncelikli 5 görev (Bu dosya her adımda güncellenmelidir).

- [ ] **MVP1-5 RC Build**: Development Build OFF seçeneğiyle Android build al ve cihazda doğrula.
- [ ] **Ghost Preview**: Blok sürüklenirken grid üzerinde önizleme (valid/invalid renkleri) + Pool sistemi + Android video kanıt.
- [ ] **Debug Spam Cleanup**: Gereksiz logları temizle (DPI check vb.).
- [ ] **Minimal Juice**: 4 SFX (Drop, Clear, Combo, GameOver) + 2 VFX (Patlama, Puan popup) + Haptic feedback.
- [ ] **Minimal Telemetry**: `session_start`, `game_over`, `score`, `lines_cleared` olaylarını takip et.
