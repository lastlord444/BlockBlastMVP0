# BİLİNEN SORUNLAR (KNOWN ISSUES)

## Aktif Sorunlar
- **Dev Toolbar**: Release build'lerde görünmüyor (Sadece Development Build/Editor için tasarlandı).
- **Board Size**: Tek gerçek kaynak `BoardConfig` asset'idir (Genellikle 10x10 olarak ayarlı). Inspector'dan ezilen değerler olursa düzeltilmelidir.
- **Ghost Preview**: Kanıt videosu henüz eksik.

## Çözülenler
- (Boş)
